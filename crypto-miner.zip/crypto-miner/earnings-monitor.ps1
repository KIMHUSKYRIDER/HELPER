param(
    [ValidateRange(5, 3600)]
    [int]$RefreshSeconds = 10
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$configPath = Join-Path $root 'config.json'
$statePath = Join-Path $root '.earnings-state.json'
$invariant = [Globalization.CultureInfo]::InvariantCulture
$atomicUnitsPerXmr = [decimal]1000000000000
$minerApi = 'http://127.0.0.1:16000/2/summary'
$backendApi = 'http://127.0.0.1:16000/2/backends'
$logicalProcessors = [Environment]::ProcessorCount

function Convert-AtomicToXmr([object]$AtomicAmount) {
    return [decimal]::Parse($AtomicAmount.ToString(), $invariant) / $atomicUnitsPerXmr
}

function Format-Xmr([decimal]$Amount) {
    return $Amount.ToString('0.000000000000', $invariant)
}

function Play-Notice {
    try { [System.Media.SystemSounds]::Asterisk.Play() } catch { }
}

function New-SpeedSparkline([double[]]$Values) {
    if ($Values.Count -eq 0) { return '' }
    $levels = '.:-=+*#%@'
    $minimum = ($Values | Measure-Object -Minimum).Minimum
    $maximum = ($Values | Measure-Object -Maximum).Maximum
    $range = $maximum - $minimum
    $result = ''

    foreach ($value in $Values) {
        $index = if ($range -gt 0) {
            [Math]::Round((($value - $minimum) / $range) * ($levels.Length - 1))
        } else {
            [Math]::Floor($levels.Length / 2)
        }
        $result += $levels[[int]$index]
    }

    return $result
}

if (-not (Test-Path -LiteralPath $configPath)) {
    Write-Host "Could not find config.json next to this monitor." -ForegroundColor Red
    Read-Host 'Press Enter to close'
    exit 1
}

$config = Get-Content -Raw -LiteralPath $configPath | ConvertFrom-Json
$wallet = [string]$config.pools[0].user
$wallet = ($wallet -split '\+')[0]

if ([string]::IsNullOrWhiteSpace($wallet) -or $wallet -eq 'YOUR_WALLET_ADDRESS') {
    Write-Host "Set your wallet in config.json first." -ForegroundColor Red
    Read-Host 'Press Enter to close'
    exit 1
}

$previousDueAtomic = $null
$previousPaidAtomic = $null
$previousSpeed = $null
$dropAlertActive = $false
$speedHistory = @()
$poolStats = $null
$lastPoolCheck = [datetime]::MinValue

if (Test-Path -LiteralPath $statePath) {
    try {
        $saved = Get-Content -Raw -LiteralPath $statePath | ConvertFrom-Json
        $previousDueAtomic = [decimal]::Parse($saved.dueAtomic.ToString(), $invariant)
        $previousPaidAtomic = [decimal]::Parse($saved.paidAtomic.ToString(), $invariant)
    } catch {
        $previousDueAtomic = $null
        $previousPaidAtomic = $null
    }
}

$shortWallet = $wallet.Substring(0, [Math]::Min(6, $wallet.Length)) + '...' + $wallet.Substring([Math]::Max(0, $wallet.Length - 6))
$host.UI.RawUI.WindowTitle = 'XMR Earnings Monitor'

Clear-Host
Write-Host 'XMR EARNINGS MONITOR' -ForegroundColor Cyan
Write-Host "Wallet: $shortWallet"
Write-Host "Live speed refresh: every $RefreshSeconds seconds"
Write-Host 'Pool balance refresh: every 60 seconds'
Write-Host 'Red means speed dropped 5% or more; green means it increased 5% or more.'
Write-Host 'A sound plays for earnings, payouts, or a new 10% speed drop.'
Write-Host 'Press Ctrl+C to stop.'
Write-Host ''

while ($true) {
    $now = Get-Date

    if (($now - $lastPoolCheck).TotalSeconds -ge 60) {
        try {
            $uri = 'https://supportxmr.com/api/miner/{0}/stats' -f [Uri]::EscapeDataString($wallet)
            $poolStats = Invoke-RestMethod -Uri $uri -TimeoutSec 20
            $lastPoolCheck = $now

            $dueAtomic = [decimal]::Parse($poolStats.amtDue.ToString(), $invariant)
            $paidAtomic = [decimal]::Parse($poolStats.amtPaid.ToString(), $invariant)

            if ($null -ne $previousDueAtomic -and $dueAtomic -gt $previousDueAtomic) {
                $increase = Convert-AtomicToXmr ($dueAtomic - $previousDueAtomic)
                Write-Host ("  + EARNED {0} XMR" -f (Format-Xmr $increase)) -ForegroundColor Green
                Play-Notice
            }

            if ($null -ne $previousPaidAtomic -and $paidAtomic -gt $previousPaidAtomic) {
                $payout = Convert-AtomicToXmr ($paidAtomic - $previousPaidAtomic)
                Write-Host ("  >>> PAYOUT DETECTED: {0} XMR <<<" -f (Format-Xmr $payout)) -ForegroundColor Magenta
                Play-Notice
            }

            @{
                dueAtomic = $dueAtomic.ToString($invariant)
                paidAtomic = $paidAtomic.ToString($invariant)
                checkedAt = $now.ToString('o')
            } | ConvertTo-Json | Set-Content -LiteralPath $statePath -Encoding UTF8

            $previousDueAtomic = $dueAtomic
            $previousPaidAtomic = $paidAtomic
        } catch {
            Write-Host ("[{0}] Pool update failed: {1}" -f $now.ToString('HH:mm:ss'), $_.Exception.Message) -ForegroundColor Red
        }
    }

    $time = $now.ToString('HH:mm:ss')

    try {
        $miner = Invoke-RestMethod -Uri $minerApi -TimeoutSec 3
        $backends = Invoke-RestMethod -Uri $backendApi -TimeoutSec 3
        $cpuBackend = $backends | Where-Object { $_.type -eq 'cpu' } | Select-Object -First 1
        $speed10 = [double]$miner.hashrate.total[0]
        $speed60 = [double]$miner.hashrate.total[1]
        $referenceSpeed = if ($speed60 -gt 0) { $speed60 } elseif ($null -ne $previousSpeed) { [double]$previousSpeed } else { 0 }
        $changePercent = if ($referenceSpeed -gt 0) { (($speed10 - $referenceSpeed) / $referenceSpeed) * 100 } else { 0 }
        $trend = 'STABLE'
        $speedColor = 'Gray'

        if ($changePercent -le -5) {
            $trend = 'DOWN'
            $speedColor = 'Red'
        } elseif ($changePercent -ge 5) {
            $trend = 'UP'
            $speedColor = 'Green'
        }

        Write-Host ("[{0}] LIVE: {1:N1} H/s (10s) | {2:N1} H/s (60s) | {3} {4:+0.0;-0.0;0.0}%" -f `
            $time, $speed10, $speed60, $trend, $changePercent) -ForegroundColor $speedColor

        $speedHistory += $speed10
        if ($speedHistory.Count -gt 30) { $speedHistory = @($speedHistory | Select-Object -Last 30) }
        $historyMin = ($speedHistory | Measure-Object -Minimum).Minimum
        $historyMax = ($speedHistory | Measure-Object -Maximum).Maximum
        Write-Host ("         5m TREND: {0}  ({1:N0}-{2:N0} H/s)" -f `
            (New-SpeedSparkline $speedHistory), $historyMin, $historyMax) -ForegroundColor $speedColor

        $activeThreads = @($cpuBackend.threads).Count
        $expectedUsage = if ($logicalProcessors -gt 0) { ($activeThreads / $logicalProcessors) * 100 } else { 0 }
        $msrStatus = if ($cpuBackend.msr) { 'ON' } else { 'OFF' }
        $hugeUsed = [int]$cpuBackend.hugepages[0]
        $hugeTotal = [int]$cpuBackend.hugepages[1]
        $tuningColor = if ($cpuBackend.msr -and $hugeUsed -eq $hugeTotal) { 'Green' } else { 'Yellow' }
        Write-Host ("         CPU: {0}/{1} threads (~{2:N0}% OS usage) | MSR {3} | Huge pages {4}/{5}" -f `
            $activeThreads, $logicalProcessors, $expectedUsage, $msrStatus, $hugeUsed, $hugeTotal) -ForegroundColor $tuningColor

        if ($changePercent -le -10 -and -not $dropAlertActive) {
            Write-Host '  ! SPEED DROP: hashrate is at least 10% below its 60-second average' -ForegroundColor Red
            Play-Notice
            $dropAlertActive = $true
        } elseif ($changePercent -gt -5) {
            $dropAlertActive = $false
        }

        $previousSpeed = $speed10
    } catch {
        Write-Host ("[{0}] LIVE: miner offline or local speed API not ready" -f $time) -ForegroundColor DarkYellow
    }

    if ($null -ne $poolStats) {
        $dueXmr = Convert-AtomicToXmr $poolStats.amtDue
        $paidXmr = Convert-AtomicToXmr $poolStats.amtPaid
        Write-Host ("         POOL: {0:N1} H/s | Pending: {1} XMR | Paid: {2} XMR | Shares: {3}" -f `
            [double]$poolStats.hash, (Format-Xmr $dueXmr), (Format-Xmr $paidXmr), $poolStats.validShares) -ForegroundColor Cyan
    }

    Start-Sleep -Seconds $RefreshSeconds
}
