@echo off
setlocal

fltmc >nul 2>&1
if errorlevel 1 (
    echo Requesting Administrator access for an accurate benchmark...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0xmrig-6.26.0"
echo Running 1M hash benchmark on your CPU (no wallet needed)...
echo This can take several minutes.
echo.
xmrig.exe --bench=1M --threads=6 --cpu-affinity=0x555
pause
