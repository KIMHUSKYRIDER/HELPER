@echo off
setlocal
cd /d "%~dp0"

echo ============================================
echo  Monero CPU Miner - Wallet Setup
echo ============================================
echo.
echo You need a Monero (XMR) wallet address.
echo Free options: Cake Wallet, Feather Wallet, monero.com/wallet
echo.
set /p WALLET="Paste your Monero wallet address: "

if "%WALLET%"=="" (
    echo No address entered. Exiting.
    pause
    exit /b 1
)

powershell -NoProfile -Command "(Get-Content '%~dp0config.json') -replace 'YOUR_WALLET_ADDRESS', '%WALLET%' | Set-Content '%~dp0config.json'"

echo.
echo Wallet saved to config.json
echo Run start-mining.cmd to begin mining.
echo.
pause
