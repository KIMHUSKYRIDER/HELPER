@echo off
:: Run as Administrator (right-click -> Run as administrator)
:: Adds exclusions for BOTH the miner and vault folders.

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Right-click this file and choose "Run as administrator"
    pause
    exit /b 1
)

set "MINER=c:\Users\Kim\Downloads\crypto-miner"
set "VAULT=c:\Users\Kim\Downloads\crypto-vault"

echo Adding Windows Security exclusions...
powershell -NoProfile -Command "Add-MpPreference -ExclusionPath '%MINER%'; Add-MpPreference -ExclusionPath '%VAULT%'"

echo.
echo Done. Excluded:
echo   %MINER%
echo   %VAULT%
echo.
echo Next: open Windows Security - Protection history - restore any quarantined XMRig/Monero files.
pause
