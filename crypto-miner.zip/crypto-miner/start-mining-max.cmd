@echo off
setlocal

fltmc >nul 2>&1
if errorlevel 1 (
    echo Requesting Administrator access for RandomX MSR and huge pages...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0xmrig-6.26.0"
echo Starting FULL-POWER CPU mining (Monero / RandomX)...
echo Pool: pool.supportxmr.com
echo Profile: 8 physical cores, higher priority, affinity 0x5555
echo The computer may feel slow while this is running.
echo.
start "XMR Earnings Monitor" powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0earnings-monitor.ps1"
xmrig.exe --config="%~dp0config.json" --threads=8 --cpu-affinity=0x5555 --cpu-priority=4
pause
