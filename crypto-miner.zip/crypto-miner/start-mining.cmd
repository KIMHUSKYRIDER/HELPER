@echo off
setlocal

fltmc >nul 2>&1
if errorlevel 1 (
    echo Requesting Administrator access for RandomX MSR and huge pages...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0xmrig-6.26.0"
echo Starting efficient CPU mining (Monero / RandomX)...
echo Pool: pool.supportxmr.com
echo Profile: 6 physical cores, affinity 0x555
echo IMPORTANT: Keep this window open. Close it = mining stops.
echo Plug in AC power for best speed (battery pause is OFF).
echo.
start "XMR Earnings Monitor" powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0earnings-monitor.ps1"
xmrig.exe --config="%~dp0config.json" --threads=6 --cpu-affinity=0x555
pause
