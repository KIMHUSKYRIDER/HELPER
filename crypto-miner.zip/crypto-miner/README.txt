Monero CPU Miner (XMRig)
========================

Your PC: AMD Ryzen 7 7730U (8 cores / 16 threads)
Expected hashrate: ~2-4 KH/s (varies with settings and thermals)

QUICK START
-----------
1. Get a Monero wallet address (free):
   - https://cakewallet.com
   - https://featherwallet.org
   - https://monero.com/wallet

2. Run setup-wallet.cmd and paste your wallet address

3. Run benchmark.cmd first (optional) to see your CPU hashrate.
   The benchmark now requests Administrator access automatically.

4. Run start-mining.cmd. It requests Administrator access automatically
   so XMRig can apply its MSR optimization and set up huge pages.

5. Sign out or restart Windows after the first elevated run if XMRig says
   huge pages are unavailable, then launch it again.

6. Track earnings at https://supportxmr.com (enter your wallet)

CPU PROFILES
------------
start-mining.cmd      - 6-core efficient profile (recommended for this laptop)
start-mining-max.cmd  - full-power 8-core mode; PC may become less responsive

Short tests on this Ryzen 7 7730U favored 6 cores: about 971 H/s versus
913 H/s with 8 cores while MSR and huge pages were unavailable. Laptop
power and thermal limits can make fewer cores both faster and more efficient.

For a fair comparison, let each profile run for at least 10 minutes on AC
power and compare the 10m average. Keep the laptop ventilated.

Use start-mining-max.cmd when you want the highest possible earnings and do
not mind the computer becoming slower. If its 10m hashrate is below the
6-core profile, use start-mining.cmd instead: the laptop is thermal-limited.

EARNINGS MONITOR
----------------
Both mining launchers open a second terminal showing pending and paid XMR.
It shows XMRig's live 10-second and 60-second speed, the pool-reported speed,
a 5-minute trend graph, active threads, MSR/huge-page status, and colors speed
drops red. A sound plays for
a new 10%% drop, earnings, or a payout. Run view-earnings.cmd to monitor
without starting XMRig.

IMPORTANT
---------
- CPU mining is slow. Expect cents per day, not dollars.
- Mining uses 100%% CPU = more heat and power use.
- Only mine on hardware you own with your consent.
- XMRig donates 1%% of hashrate to the developer (standard).

FILES
-----
xmrig-6.26.0/   - Miner binary (official XMRig v6.26.0)
config.json     - Pool and wallet settings
start-mining.cmd
start-mining-max.cmd
benchmark.cmd
setup-wallet.cmd
view-earnings.cmd
earnings-monitor.ps1
