@echo off
title XMR Earnings Monitor
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0earnings-monitor.ps1"
pause
